prediction_1 = ""
prediction_2 = ""

Webcam.set({
    height: 300,
    width: 350,
    image_format: 'png',
    png_quality: 90
})

camera = document.getElementById("camera")
Webcam.attach('#camera')

function capture() {
    Webcam.snap(function (data_uri) {
        document.getElementById("result").innerHTML = "<img id='captured_image' src='" + data_uri + "'>"
    })
}

//https://teachablemachine.withgoogle.com/models/VgtsVeuN9/

console.log("ml5 version:", ml5.version)

classifier = ml5.imageClassifier("https://teachablemachine.withgoogle.com/models/VgtsVeuN9/model.json", modelloaded)

function modelloaded() {
    console.log("Your model has been loaded successfully!")
}

// this function will be called later onwards

function speak() {
    var synth = window.speechSynthesis
    speech_data1 = " The first prediction is " + prediction_1
    speech_data2 = " The second prediction is " + prediction_2
    var utterThis = new SpeechSynthesisUtterance(speech_data1 + speech_data2)
    synth.speak(utterThis)
}

function check() {
    img = document.getElementById("captured_image")
    classifier.classify(img, gotresult)
}

function gotresult(error, result) {
    if (error) {
        console.error(error)
    } else {
        console.log(result)
        prediction_1 = result[0].label
        prediction_2 = result[1].label

        document.getElementById("result_1").innerHTML = prediction_1
        document.getElementById("result_2").innerHTML = prediction_2

        speak()

        if (prediction_1 == "Thumbs Up") {
            document.getElementById("emoji_1").innerHTML = "&#128077"
        }

        if (prediction_1 == "Peace") {
            document.getElementById("emoji_1").innerHTML = "&#9996"
        }

        if (prediction_1 == "Paper") {
            document.getElementById("emoji_1").innerHTML = "&#9995"
        }


        if (prediction_2 == "Thumbs Up") {
            document.getElementById("emoji_2").innerHTML = "&#1280777"
        }

        if (prediction_2 == "Peace") {
            document.getElementById("emoji_2").innerHTML = "&#9996"
        }

        if (prediction_2 == "Paper") {
            document.getElementById("emoji_2").innerHTML = "&#9995"
        }


    }
}